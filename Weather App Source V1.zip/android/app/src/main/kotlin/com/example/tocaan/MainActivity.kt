package com.example.tocaan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
